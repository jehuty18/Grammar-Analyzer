//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport

var str = "Hello, playground"

class MainViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate{
    
    let yPos: CGFloat = 150
    var label = UITextField()
    var responseView = UITableView()
    var languageSegment: UISegmentedControl = UISegmentedControl()
    var languageSelected: String = ""
    let height: CGFloat = 20
    
    var arrayOfWordsForTableView: [String] = []{
        didSet{
            self.responseView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        setTextField()
        setResponseField()
        setSegmentControl()
    }
    
    //MARK: Setter functions
    func setTextField() {
        
        label = UITextField(frame: CGRect(x: 50, y: Int(yPos), width: Int(self.view.frame.maxX - 50), height: 20))
        label.adjustsFontSizeToFitWidth = true
        label.adjustsFontForContentSizeCategory = true
        label.center = CGPoint(x: self.view.frame.midX, y: yPos)
        label.placeholder = "Hello World!"
        label.borderStyle = .roundedRect
        label.sizeThatFits(self.view.frame.size)
        label.textColor = .black
        label.isEnabled = true
        label.delegate = self
        self.view.addSubview(label)
    }
    
    func setResponseField() {
        
        responseView = UITableView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.bounds.maxY/2))
        responseView.center = CGPoint(x: self.view.frame.midX, y: yPos + responseView.frame.height/2 + 50)
        responseView.delegate = self
        responseView.dataSource = self
        responseView.isHidden = true
        responseView.register(UITableViewCell.self, forCellReuseIdentifier: "myCell")
        view.addSubview(responseView)
    }
    
    func setSegmentControl() {
        
        let xPosition: CGFloat = 0
        let yPosition: CGFloat = yPos - 30
        let segWidth: CGFloat = self.view.frame.width/2
        let segHeight: CGFloat = height
        
        languageSegment = UISegmentedControl(frame: CGRect(x: xPosition, y: yPosition, width: segWidth, height: segHeight))
        languageSegment = UISegmentedControl(items: ["en","it"])
        languageSegment.center = CGPoint(x: self.view.frame.midX, y: yPosition)
        languageSegment.selectedSegmentIndex = 0
        languageSegment.tintColor = .blue
        self.view.addSubview(languageSegment)
    }
    
    //MARK: TableView delegate methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayOfWordsForTableView.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! UITableViewCell
        cell.textLabel?.text = self.arrayOfWordsForTableView[indexPath.row]
        
        return cell
    }
    
    //MARK: TextField delegate methods
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.responseView.isHidden = true
        self.label.clearButtonMode = UITextFieldViewMode.whileEditing
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.responseView.isHidden = true
        self.arrayOfWordsForTableView.removeAll()
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if let text = self.label.text {
            
            self.responseView.isHidden = false
            let question = text
            let language = languageSegment.titleForSegment(at: languageSegment.selectedSegmentIndex)
            let options: NSLinguisticTagger.Options = [.omitWhitespace, .joinNames]
            let schemes = NSLinguisticTagger.availableTagSchemes(forLanguage: language!)
            let tagger = NSLinguisticTagger(tagSchemes: schemes, options: Int(options.rawValue))
            let range = NSRange(location: 0, length: question.characters.count)
            
            tagger.string = question
            tagger.enumerateTags(in: range, scheme: NSLinguisticTagScheme.nameTypeOrLexicalClass, options: options) { (tag, tokerRange, sentenceRange, stop) in
                
                let token = (question as NSString).substring(with: tokerRange)
                self.arrayOfWordsForTableView.append("\((tag?._rawValue)!): \(token)\n")
            }
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textFieldShouldClear(textField)
        textFieldShouldEndEditing(textField)
        return true
    }
    
}

PlaygroundPage.current.liveView = MainViewController()
